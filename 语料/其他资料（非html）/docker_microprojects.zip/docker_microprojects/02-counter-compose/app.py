import os
import time

from flask import Flask, jsonify
from redis import Redis
from redis.exceptions import ConnectionError

app = Flask(__name__)
redis_client = Redis(
    host=os.getenv("REDIS_HOST", "redis"),
    port=int(os.getenv("REDIS_PORT", "6379")),
    decode_responses=True,
)


def increment_with_retry(max_attempts: int = 10) -> int:
    """Redis may still be starting when the web container starts."""
    for attempt in range(1, max_attempts + 1):
        try:
            return int(redis_client.incr("visits"))
        except ConnectionError:
            if attempt == max_attempts:
                raise
            time.sleep(0.5)
    raise RuntimeError("unreachable")


@app.get("/")
def index():
    count = increment_with_retry()
    return jsonify(
        message="Hello from the web container",
        visits=count,
        redis_host=os.getenv("REDIS_HOST", "redis"),
    )


@app.get("/health")
def health():
    redis_client.ping()
    return {"status": "ok"}


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
