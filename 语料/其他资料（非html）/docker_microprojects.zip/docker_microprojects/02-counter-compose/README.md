# 微型项目 2：Flask + Redis 访问计数器

```bash
docker compose up --build -d
docker compose ps
docker compose logs -f web
curl http://localhost:8000/
docker compose exec redis redis-cli GET visits
docker compose down
docker compose up -d
curl http://localhost:8000/
docker compose down -v
```

`docker compose down` 不删除命名卷，所以计数会保留；`docker compose down -v` 会删除命名卷。
