# 微型项目 1：静态网站镜像

```bash
docker build -t hello-docker:v1 .
docker run -d --name hello-web -p 127.0.0.1:8080:80 hello-docker:v1
docker ps
docker logs hello-web
docker exec hello-web nginx -T
docker inspect hello-web
docker stop hello-web
docker rm hello-web
```

打开 http://localhost:8080 。
